from aiogram.types import user
import sqlite3
from datetime import datetime

conn = sqlite3.connect('db.db')
cursor = conn.cursor()

async def is_user_exists(id_user):
    """ проверка на существование юзера в базе и подписки на бота """
    cursor.execute("""
           SELECT id FROM users WHERE id_user = ? AND is_sub_bot = 1
       """, (id_user,))
    rst = cursor.fetchone()
    print(rst)
    return False if rst is None else True


async def is_now_balance(id_user):
    """ возвращает текущий баланс пользователя """
    cursor.execute("""
        SELECT now_balance FROM users WHERE id_user = ? LIMIT 1""", (id_user,))
    rst = cursor.fetchone()
    return rst[0] if rst else None


async def update_now_balance(id_user, sum_balance, is_add=False):
    """ Вычитаем/добавляем к now_balance сумму sum_balance.
    По-умолчанию сумма вычитается. Сложение/вычитание регулируется флагом is_add"""
    sum_balance = abs(sum_balance) if is_add else -abs(sum_balance)
    cursor.execute("""
        UPDATE users SET now_balance = now_balance + ?
         WHERE id_user = ?""", (sum_balance, id_user,))
    conn.commit()


async def add_referrer(id_ref):
    """ обновляем информацию пользователю, по чьей ссылке подключились """
    cursor.execute("""
        UPDATE users SET 
        all_balance = all_balance + 0.5,
        now_balance = now_balance + 0.5,
        cnt_referrer = cnt_referrer + 1
        WHERE id_user = ?""", (id_ref,))
    conn.commit()
    return cursor.rowcount


async def create_user(id_user: int, fname, lname, username, ref=0):
    """ создание юзера """
    ts_now = int(datetime.timestamp(datetime.now()))
    cursor.execute("""
        INSERT INTO users (id_user, fname, lname, username, referrer, ts_start) 
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(id_user) DO UPDATE SET
            is_sub_bot = 1
          WHERE id_user = ?;""", (id_user, fname, lname, username, ref, ts_now, id_user))
    conn.commit()


async def create_question(ans, cost, all_answers, text_question, description):
    """ создание вопроса """
    ts_now = int(datetime.timestamp(datetime.now()))
    cursor.execute("""INSERT INTO questions 
                    (is_answer, cost, all_answ, date, text_question, description) VALUES (?, ?, ?, ?, ?, ?)""",
                   (ans, cost, all_answers, ts_now, text_question, description))
    conn.commit()
    lid = cursor.lastrowid
    return lid


async def insert_all_answers_question(id_question, lst_info):
    """ заполнение вариантов ответа и подсказок """
    all_info = []
    for i in lst_info:
        all_info.append(((id_question, )+i))
    query = """INSERT INTO all_answers_questions (id_question, id_answer, answer, answer_prompt)
            VALUES (?, ?, ?, ?)"""
    cursor.executemany(query, all_info)
    conn.commit()


async def update_msg_id_question(id_q, msg_id):
    """ обновление id сообщения с вопросом для последующего изменения его состояния (делать неактивным) """
    cursor.execute("""
        UPDATE questions SET msg_id = ? WHERE id = ?""", (msg_id, id_q))
    conn.commit()
    return cursor.rowcount


async def get_id_msg_question(id_q):
    """ возвращает инфу для вопроса id_q """
    cursor.execute(""" SELECT msg_id, text_question, description FROM questions WHERE id=? LIMIT 1 """,
                   (id_q,))
    rst = cursor.fetchone()
    return rst if rst else False


async def get_prompt_question(id_q, id_a):
    cursor.execute(""" 
        SELECT answer_prompt 
        FROM all_answers_questions 
        WHERE id_question=? AND id_answer=?""", (id_q, id_a))
    rst = cursor.fetchone()
    return rst[0] if rst else None


async def is_active_question(id_q):
    """  """
    cursor.execute(""" SELECT state FROM questions WHERE id = ?""", (id_q,))
    rst = cursor.fetchone()
    return rst[0] if rst else False


async def update_state_question(id_q, state=False):
    """ обновление статуса вопроса """
    cursor.execute(""" 
        UPDATE questions SET state = ? WHERE id = ?""", (state, id_q,))
    conn.commit()
    return cursor.rowcount


async def statistic_question(id_question):
    """ кол-во ответов на вопрос с id id_question """
    cursor.execute("""
     SELECT aq.id_answer, answer, count (an.id_answer), aq.id_question FROM all_answers_questions aq
     LEFT JOIN answers an ON an.id_question = ? AND an.id_answer = aq.id_answer
     WHERE aq.id_question = ?
     GROUP BY aq.id_answer""", (id_question, id_question))
    rst = cursor.fetchall()
    all_answers = 0
    for i in rst:
        all_answers += i[2]

    tmp_rst = []
    for i in rst:
        tmp_rst.append({
            'percent': round((i[2]/all_answers * 100), 2) if all_answers != 0 else 0,
            'cnt': i[2],
            'text': i[1],
            'id': i[0],
        })
    print(tmp_rst)
    return tmp_rst


async def count_invite(id_user: int):
    """ кол-во приглашенных пользователей """
    cursor.execute("""
            SELECT cnt_referrer FROM users WHERE id_user = ? LIMIT 1
        """, (id_user,))
    cnt_invite = cursor.fetchone()
    return cnt_invite[0] if cnt_invite else 0


async def is_answered(id_user: int, id_asn):
    """ проверка, отвечал ли юзер id_user на вопрос с id id_asn"""
    cursor.execute("""
        SELECT correctly_anw FROM answers WHERE id_user = ? AND id_question = ?
    """, (id_user, id_asn))
    rst = cursor.fetchone()
    return False if rst is None else True


async def application_refund(id_user, method, sum_ref, comm):
    ts_now = int(datetime.timestamp(datetime.now()))
    cursor.execute("""
        INSERT INTO refund (id_user, sum_refund, method, comments, date_app)
        VALUES (?, ?, ?, ?, ?)""", (id_user, sum_ref, method, comm, ts_now))
    conn.commit()


async def update_state_refund(id_app, new_stat=True):
    cursor.execute("""
        UPDATE refund SET state = ? WHERE id = ?""", (new_stat, id_app,))
    conn.commit()


async def all_active_application():
    """ список всех активных заявок """
    cursor.execute("""
        SELECT refund.id_user, refund.sum_refund, refund.method, refund.comments, users.fname, users.username, refund.id 
        FROM refund
        LEFT JOIN users ON users.id_user = refund.id_user
        WHERE refund.state = 0
    """)
    rst = cursor.fetchall()
    print(rst)
    if rst:
        result = []
        for i in rst:
            tmp = {
                'id_user': i[0],
                'sum_refund': i[1],
                'method': i[2],
                'comments': i[3],
                'u_name': i[4],
                'username': i[5],
                'id': i[6],
            }
            result.append(tmp)
        return result
    else:
        return None


async def insert_answer(id_user, u_fname, u_lname, u_name, id_q, id_a, is_correct, cost):
    """ запись в базу ответа на вопрос """
    cursor.execute("""
        INSERT INTO answers (id_user, id_question, id_answer, correctly_anw) 
        VALUES(?, ?, ?, ?)""", (id_user, id_q, id_a, is_correct))

    ts_now = int(datetime.timestamp(datetime.now()))
    add_sum = cost if is_correct else 0
    cursor.execute("""
        INSERT INTO users (id_user, fname, lname, username, is_sub_bot, all_balance, now_balance,ts_start, all_answer, correctly_anw)
        VALUES(?, ?, ?, ?, 0, ?, ?, ?, 1, ?)
        ON CONFLICT(id_user) DO UPDATE SET
            all_balance=all_balance + ?,
            now_balance=now_balance + ?,
            all_answer=all_answer + 1 
          WHERE id_user = ?;
    """, (id_user, u_fname, u_lname, u_name, add_sum, add_sum, ts_now, is_correct, add_sum, add_sum, id_user))
    await recalc_percent_cor(id_user)
    conn.commit()


async def recalc_percent_cor(id_user):
    """ перерасчет процента правильных ответов """
    cursor.execute(""" SELECT all_answer, correctly_anw FROM users
        WHERE id_user = ? LIMIT 1""", (id_user,))
    stats = cursor.fetchone()
    if stats:
        c_ans = round(((stats[1] / stats[0]) * 100 if stats[0] != 0 else 0), 2)
        cursor.execute("""
            UPDATE users SET
            percent_cor = ?
            WHERE id_user = ?
        """, (c_ans, id_user,))
        conn.commit()


async def user_statistics(id_user):
    cursor.execute("""
            SELECT all_answer, correctly_anw, now_balance, all_balance, percent_cor, cnt_referrer FROM users 
            WHERE id_user = ?
        """, (id_user,))
    stats = cursor.fetchone()
    if stats:
        return {
            'all_ans': stats[0],
            'cor_pr': stats[4],
            'balance': stats[2],
            'all_balance': stats[3],
            'cor_ans': stats[1],
            'invite': stats[5],
        }
    else:
        return {}


async def stat_rating(type_stat):
    print(type_stat)
    if type_stat == 'percent_cor':
        cursor.execute("""
            SELECT fname, lname, username, percent_cor FROM users ORDER BY percent_cor DESC LIMIT 10
        """)
    elif type_stat == 'correctly_anw':
        cursor.execute("""
            SELECT fname, lname, username, correctly_anw FROM users ORDER BY correctly_anw DESC LIMIT 10
        """)
    elif type_stat == 'all_answer':
        cursor.execute("""
            SELECT fname, lname, username, all_answer FROM users ORDER BY all_answer DESC LIMIT 10
        """)
    elif type_stat == 'all_balance':
        cursor.execute("""
            SELECT fname, lname, username, all_balance FROM users ORDER BY all_balance DESC LIMIT 10
        """)
    elif type_stat == 'cnt_referrer':
        cursor.execute("""
            SELECT fname, lname, username, cnt_referrer FROM users ORDER BY cnt_referrer DESC LIMIT 10
        """)
    stat = cursor.fetchall()
    print(stat)
    if stat:
        rst = []
        for u in stat:
            tmp = {
                'fname': u[0],
                'lname': u[1],
                'username': u[2],
                'rating': u[3],
            }
            rst.append(tmp)

        return rst
