from aiogram.types import KeyboardButton, ReplyKeyboardMarkup
import utils


def main_keyboard(id_user, is_main_menu = False):
    lst_admins = utils.config.admins
    if id_user in lst_admins:
        main_key = KeyboardButton('🛠 Создать опрос')
    else:
        main_key = KeyboardButton('🧩 Принять участие')
    my_stats = KeyboardButton('📊 Моя статистика')
    rating = KeyboardButton('🏆 Рейтинг')
    invite = KeyboardButton('🙋 ‍Пригласить друга')
    money = KeyboardButton('💰 Вывод средств')
    info = KeyboardButton('ℹ Информация')
    advertising = KeyboardButton('📝 Отзывы и выплаты')
    _main_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    if not is_main_menu:
        _main_keyboard.add(main_key)
    _main_keyboard.add(my_stats, rating)
    if not is_main_menu:
        _main_keyboard.add(invite, money)
    _main_keyboard.add(info, advertising)
    if is_main_menu:
        _main_keyboard.add(KeyboardButton('🔙 Главное меню'))
    return _main_keyboard
