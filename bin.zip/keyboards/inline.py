from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.callback_data import CallbackData
import utils


type_arrival = CallbackData('arrival', 'type', 'id')
inline_answer = CallbackData('answer', 'id_question', 'id_answer', 'true_ans', 'cost', 'type')
inline_rating = CallbackData('rating', 'type')
inline_participate = CallbackData('participate', 'type')
inline_refund = CallbackData('refund', 'type')
inline_suc_refund = CallbackData('refund', 'id_user', 'sum_ref', 'id_app')
inline_cancel_refund = CallbackData('cancel_refund', 'type')
inline_info = CallbackData('info', 'type')
inline_results = CallbackData('result', 'id')


def inline_suc_refund_btn(id_user, sum_ref, id_app):
    inline_btn = InlineKeyboardMarkup().add(
        InlineKeyboardButton('Выплачено', callback_data=inline_suc_refund.new(id_user=id_user, sum_ref=sum_ref, id_app=id_app)),
    )
    return inline_btn


def inline_refund_btn():
    inline_btn = InlineKeyboardMarkup().add(
        InlineKeyboardButton('🌐 WebMoney', callback_data=inline_refund.new(type='webmoney')),
        InlineKeyboardButton('💳 На карту', callback_data=inline_refund.new(type='card'))
    )
    inline_btn.add(
        InlineKeyboardButton('🔙 Отмена', callback_data=inline_cancel_refund.new(type='cancel')),
    )
    return inline_btn


def inline_cancel_refund_btn():
    return InlineKeyboardMarkup().add(
        InlineKeyboardButton('Отмена', callback_data=inline_cancel_refund.new(type='cancel')),
    )


def inline_participate_btn():
    inline_btn = InlineKeyboardMarkup().add(
        InlineKeyboardButton('Правила', callback_data=inline_participate.new(type='rules')),
        InlineKeyboardButton('Участвовать', url='https://t.me/testquiz_quiz')
    )
    return inline_btn


def inline_results_question(id_q):
    inline_btn = InlineKeyboardMarkup().add(
        InlineKeyboardButton('Результаты', callback_data=inline_results.new(id=id_q)),
    )
    return inline_btn

def inline_info_btn():
    link_channel = utils.config.channel_name_info
    inline_btn = InlineKeyboardMarkup().add(
        InlineKeyboardButton('💬 Чат ITшников', url=link_channel),
        InlineKeyboardButton('❗ О боте', callback_data=inline_info.new(type='about'))
    )
    inline_btn.add(
        InlineKeyboardButton('📢 Реклама', callback_data=inline_info.new(type='advertising')),
    )
    return inline_btn


def inline_comments_btn():
    link_channel = utils.config.channel_name_comment
    inline_btn = InlineKeyboardMarkup().add(
        InlineKeyboardButton('Перейти', url=link_channel)
    )
    return inline_btn


def inline_rating_btn():
    btn_all_answer = InlineKeyboardButton('ответам', callback_data=inline_rating.new(type='all_answer'))
    btn_all_balance = InlineKeyboardButton('Баланс за все время', callback_data=inline_rating.new(type='all_balance'))
    btn_invite = InlineKeyboardButton('рефералам', callback_data=inline_rating.new(type='cnt_referrer'))
    btn_corr_ans = InlineKeyboardButton('правильным ответам', callback_data=inline_rating.new(type='correctly_anw'))
    btn_ratio = InlineKeyboardButton('процентному соотношению', callback_data=inline_rating.new(type='percent_cor'))
    inline_btn = InlineKeyboardMarkup().add(
        btn_all_answer, btn_all_balance, btn_invite, btn_corr_ans, btn_ratio,
    )
    return inline_btn


def inline_type_arrival(user_id):
    inline_btn1 = InlineKeyboardButton('Приход', callback_data=type_arrival.new(type = 0, id = user_id))
    inline_btn2 = InlineKeyboardButton('Уход', callback_data=type_arrival.new(type = 1, id = user_id))
    inline_btn3 = InlineKeyboardButton('Вернулся', callback_data=type_arrival.new(type = 2, id = user_id))
    inline_btn4 = InlineKeyboardButton('Отошел', callback_data=type_arrival.new(type = 3, id = user_id))
    inline_btn = InlineKeyboardMarkup().add(inline_btn1, inline_btn2, inline_btn3, inline_btn4)
    return inline_btn


def inline_answer_options(question_id, options, true_answer, cost):
    print(options)
    inline_btns = []
    for option in options:
        # for option_val, option_key in i.items():
        inline_btns.append(
            InlineKeyboardButton(option['answer'], callback_data=inline_answer.new(
                id_question=question_id,
                id_answer=option['number'],
                true_ans=true_answer,
                cost=cost,
                type='answer',
            ))
        )
    inline_btn = InlineKeyboardMarkup(row_width=2).add(*inline_btns)
    inline_btn.add(
        InlineKeyboardButton('Результаты', callback_data=inline_results.new(
                id=question_id,
        ))
    )
    inline_btn.add(
        InlineKeyboardButton('Личный кабинет', url=utils.config.username_bot)
    )
    return inline_btn




