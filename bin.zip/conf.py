import logging
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware
import sqlite3
import utils

conn = sqlite3.connect('db.db')
cursor = conn.cursor()
cursor.execute("""CREATE TABLE if not exists questions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        is_answer INT,
        cost REAL DEFAULT 0,
        msg_id INT,
        date INTEGER,
        text_question TEXT,
        description TEXT,
        state BOOL DEFAULT 1)""")


cursor.execute("""CREATE TABLE if not exists all_answers_questions(
    id_question INT,
    id_answer INT,
    answer TEXT,
    answer_prompt TEXT)""")


cursor.execute("""CREATE TABLE if not exists answers(
        id_user INT,
        id_question INT,
        id_answer INT,
        correctly_anw BOOL)""")


cursor.execute("""CREATE TABLE if not exists refund(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_user INTEGER,
        sum_refund REAL,
        method VARCHAR (50),
        comments TEXT,
        date_app INTEGER,
        state BOOL DEFAULT 0)""")


cursor.execute("""CREATE TABLE if not exists users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_user INTEGER UNIQUE,
        fname VARCHAR(50),
        lname VARCHAR(50),
        username VARCHAR(50),        
        is_active BOOL DEFAULT 1,
        is_admin BOOL DEFAULT 0,
        is_sub_bot DEFAULT 1,
        all_balance REAL DEFAULT 0,
        now_balance REAL DEFAULT 0,
        referrer VARCHAR(100),
        cnt_referrer INTEGER DEFAULT 0,
        ts_start INTEGER,
        all_answer INTEGER DEFAULT 0,
        percent_cor REAL DEFAULT 0,
        correctly_anw INTEGER DEFAULT 0)""")


conn.commit()


bot = Bot(token=utils.config.token)
memory_storage = MemoryStorage()
dp = Dispatcher(bot, storage=memory_storage)
logging.basicConfig(level=logging.INFO)


class BlockMiddleware(BaseMiddleware):

    async def on_process_message(self, msg: types.Message, data: dict):
        print(msg)
        # Проверяем, админ ли в msg.
        #if не_админ:
        #    raise CancelHandler()


    async def on_pre_process_callback_query(self, call: types.CallbackQuery, data: dict):
        print(call)
        print(data)