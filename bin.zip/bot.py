from aiogram import executor
from conf import dp, BlockMiddleware
import handlers


if __name__ == "__main__":
    dp.middleware.setup(BlockMiddleware())
    executor.start_polling(dp, skip_updates=True)