from aiogram import types
from conf import dp, bot
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
import keyboards
import utils


class RefundStat(StatesGroup):
    method = State()
    sum_refund = State()
    comment = State()


@dp.message_handler(commands=['start'])
async def start_user(msg: types.Message):
    """ /start бота """
    id_user = msg.from_user.id
    lname = msg.from_user.last_name
    fname = msg.from_user.first_name
    username = msg.from_user.username
    is_new_user = await utils.db.is_user_exists(id_user)
    if not is_new_user:
        # запись информации о пользователе в базу
        referrer = msg.get_args()
        await utils.db.create_user(id_user, fname, lname, username, referrer)
        # проверка на реферрера и обновление данных у реферрера
        print(referrer)
        if referrer and referrer != id_user:
            is_referrer = await utils.db.add_referrer(referrer)
            if is_referrer:
                msg_ref = "Отлично! По вашей реферальной ссылке кто-то зашел" \
                          "вы получили за это 0.5 рублей"
                print(await bot.send_message(referrer, msg_ref))

    print(is_new_user)
    await bot.send_message(msg.from_user.id, 'Добро пожаловать!',
                           reply_markup=keyboards.keyboards.main_keyboard(msg.from_user.id))


@dp.message_handler(commands=['profile'])
@dp.message_handler(text='📊 Моя статистика')
async def my_statistics(msg: types.Message):
    """ персональная статистика пользователя """
    user_st = await utils.db.user_statistics(msg.from_user.id)
    msg_st = f"📝 ответов: {user_st.get('all_ans', 0)}\n" \
             f"✔ Правильных ответов: {user_st.get('cor_ans', 0)}\n" \
             f"🧮 Процентное соотношение правильных ответов: {user_st.get('cor_pr', 0)}%\n" \
             f"💳 Баланс: {user_st.get('balance', 0)}\n" \
             f"💰 Заработанных средств за весь период: {user_st.get('all_balance', 0)}\n" \
             f"👥 Приглашенных пользователей: {user_st.get('invite', 0)}"
    await bot.send_message(msg.from_user.id, msg_st)


@dp.message_handler(text='🙋 ‍Пригласить друга')
async def my_invite(msg: types.Message):
    """ Хендлер рефераллов """
    cnt_invite = await utils.db.count_invite(msg.from_user.id)
    link_ref = f'https://t.me/quizsamplebot?start={msg.from_user.id}'
    text_msg = "За каждого приглашенного друга по реферальной ссылке вы получите 0.5 рублей.\n" \
               f"👥 Вы пригласили {cnt_invite} человек\n" \
               f"👤 Ваша реферальная ссылка: {link_ref}"
    await bot.send_message(msg.from_user.id, text_msg)


@dp.message_handler(text='ℹ Информация')
async def information(msg: types.Message):
    text_msg = 'ℹ Информация'
    await bot.send_message(msg.from_user.id, text_msg, reply_markup=keyboards.inline.inline_info_btn())


@dp.message_handler(commands=['otzyv'])
@dp.message_handler(text='📝 Отзывы и выплаты')
async def advertising(msg: types.Message):
    text_msg = 'Какой-то текст про отзывы'
    await bot.send_message(msg.from_user.id, text_msg,
                           reply_markup=keyboards.inline.inline_comments_btn())


@dp.message_handler(commands=['raiting'])
@dp.message_handler(text='🏆 Рейтинг')
async def rating(msg: types.Message):
    text_msg = 'Рейтинг по:'
    await bot.send_message(msg.from_user.id, text_msg, reply_markup=keyboards.inline.inline_rating_btn())


@dp.message_handler(text='💰 Вывод средств')
async def refund(msg: types.Message):
    await RefundStat.method.set()
    await bot.send_message(
        msg.from_user.id,
        'Куда выводить:',
        reply_markup=keyboards.inline.inline_refund_btn()
    )


@dp.message_handler(commands=['go'])
@dp.message_handler(text='🧩 Принять участие')
async def participate(msg: types.Message):
    await bot.send_message(msg.from_user.id, 'Выбери действие:', reply_markup=keyboards.inline.inline_participate_btn())


@dp.message_handler(commands=['about'])
@dp.callback_query_handler(keyboards.inline.inline_info.filter(type='about'))
async def about_bot(msg: types.Message):

    text_msg = 'Текст про бота'
    await bot.send_message(msg.from_user.id, text_msg)


@dp.callback_query_handler(keyboards.inline.inline_participate.filter(type='rules'))
async def rules(call: types.CallbackQuery, callback_data: dict):
    """ хэндлер для кнопки "Правила" """
    await bot.send_message(call.from_user.id, 'Текст правил')
    await call.answer()


@dp.message_handler(text='🔙 Главное меню', state=RefundStat)
@dp.callback_query_handler(keyboards.inline.inline_cancel_refund.filter(), state=RefundStat)
async def cancel_refund(msg: types.Message, state: FSMContext):
    """ Отмена создания заявки на вывод """
    await state.finish()
    await bot.send_message(msg.from_user.id, 'Процесс отменен.')


@dp.callback_query_handler(keyboards.inline.inline_refund.filter(), state=RefundStat.method)
async def refund_call(call: types.CallbackQuery, callback_data: dict, state: FSMContext):
    method_ref = callback_data['type']
    print(method_ref)
    await state.update_data(method=method_ref)
    await RefundStat.next()
    await bot.send_message(call.from_user.id, 'Какую сумму выводить:',
                           reply_markup=keyboards.keyboards.main_keyboard(call.from_user.id,
                                                                          is_main_menu=True))
    await call.answer()


@dp.message_handler(state=RefundStat.sum_refund, content_types=types.ContentTypes.TEXT)
async def sum_refund(msg: types.Message, state: FSMContext):
    try:
        _sum_refund = float(msg.text)
        await state.update_data(sum_refund=_sum_refund)
        min_refund = 2
        if _sum_refund < min_refund:
            await bot.send_message(msg.from_user.id, f'Минимальная сумма к выплате {min_refund}р.',
                                   reply_markup=keyboards.keyboards.main_keyboard(msg.from_user.id,
                                                                                  is_main_menu=True))
            return
        now_balance = await utils.db.is_now_balance(msg.from_user.id)
        if now_balance < _sum_refund:
            await bot.send_message(msg.from_user.id, f'На твоем счету недостаточно средств. У тебя {now_balance}р.',
                                   reply_markup=keyboards.keyboards.main_keyboard(msg.from_user.id,
                                                                                  is_main_menu=True))
            return
        await bot.send_message(msg.from_user.id, 'Куда именно выводить (номер кошелька, карты и т.д.):',
                               reply_markup=keyboards.keyboards.main_keyboard(msg.from_user.id,
                                                                              is_main_menu=True))
        await RefundStat.next()
    except ValueError:
        await bot.send_message(msg.from_user.id, 'Ошибка. Необходимо ввести число\nКакую сумму выводить:',
                               reply_markup=keyboards.keyboards.main_keyboard(msg.from_user.id,
                                                                              is_main_menu=True))
        return


@dp.message_handler(state=RefundStat.comment, content_types=types.ContentTypes.TEXT)
async def comments_refund(msg: types.Message, state: FSMContext):
    await state.update_data(comments=msg.text)
    refund_info = await state.get_data()
    print(refund_info)
    await state.finish()
    # создаем заявку в базе
    await utils.db.application_refund(
        msg.from_user.id,
        refund_info['method'],
        refund_info['sum_refund'],
        refund_info['comments'],
    )
    # вычитаем сумму из текущего баланса
    await utils.db.update_now_balance(
        msg.from_user.id,
        refund_info['sum_refund'],
    )
    await bot.send_message(msg.from_user.id, 'Заявка отправлена, ожидайте')


@dp.message_handler(commands=['заявки'])
async def all_applications_refund(msg: types.Message):
    all_app = await utils.db.all_active_application()
    if all_app:
        for i in all_app:
            username = f"(@{i['username']})" if i['username'] else ''
            msg_text = f"{i['u_name']} {username}\n{i['method']} - {i['sum_refund']}р.\n{i['comments']}"

            await bot.send_message(
                msg.from_user.id, msg_text,
                reply_markup=keyboards.inline.inline_suc_refund_btn(i['id_user'], i['sum_refund'], i['id'])
            )
    else:
        await bot.send_message(msg.from_user.id, 'Заявок на выплаты нет.')


@dp.callback_query_handler(keyboards.inline.inline_suc_refund.filter())
async def suc_refund(call: types.CallbackQuery, callback_data: dict):
    print(callback_data)
    # ставим заявку в статус неактивной
    await utils.db.update_state_refund(callback_data['id_app'])

    msg_text = f"Сумма {callback_data['sum_ref']} выплачена!"
    await bot.send_message(callback_data['id_user'], msg_text)
    await call.answer()

# @dp.message_handler()
# async def tete(msg: types.Message):
#     await utils.db.recalc_percent_cor(msg.from_user.id)
