from aiogram import types
from conf import dp, bot
from aiogram.utils.callback_data import CallbackData
import keyboards
import utils


@dp.callback_query_handler(keyboards.inline.inline_results.filter())
async def btn_result(call: types.CallbackQuery, callback_data: dict):
    print(callback_data)
    is_subscriber = await bot.get_chat_member(utils.config.channel_id, call.from_user.id)
    is_subscriber = True if is_subscriber['status'] != 'left' else False
    if not is_subscriber:
        await call.answer('Ты не подписан на канал!', show_alert=True)
        return
    is_answered = await utils.db.is_answered(call.from_user.id, callback_data['id'])
    is_active_question = await utils.db.is_active_question(callback_data['id'])
    if is_answered or not is_active_question:
        rst_msg = await utils.db.statistic_question(int(callback_data['id']))
        if rst_msg:
            msg_txt = ''
            for i in rst_msg:
                msg_txt += f"{i.get('id')}. {i.get('text')} - {i.get('cnt')} ({i.get('percent')})%\n"
            await call.answer(msg_txt, show_alert=True)
    else:
        await call.answer('Сперва нужно проголосовать!')
    await call.answer()


@dp.callback_query_handler(keyboards.inline.inline_answer.filter())
async def bnt_question(call: types.CallbackQuery, callback_data: dict):
    print(callback_data)
    is_subscriber = await bot.get_chat_member(utils.config.channel_id, call.from_user.id)
    is_subscriber = True if is_subscriber['status'] != 'left' else False
    if not is_subscriber:
        await call.answer('Ты не подписан на канал!', show_alert=True)
        return
    is_active_question = await utils.db.is_active_question(callback_data['id_question'])
    if not is_active_question and (callback_data['type'] != 'result'):
        await call.answer('Вопрос неактивен', show_alert=True)
        return

    is_answered = await utils.db.is_answered(call.from_user.id, callback_data['id_question'])
    if callback_data['type'] == 'answer':
        is_corr_ans = callback_data['true_ans'] == callback_data['id_answer']
        if is_answered:
            await call.answer('Ты уже голосовал!', show_alert=True)
        else:
            await utils.db.insert_answer(
                call.from_user.id,
                call.from_user.first_name,
                call.from_user.last_name,
                call.from_user.username,
                callback_data['id_question'],
                callback_data['id_answer'],
                is_corr_ans,
                callback_data['cost'],
            )
            if is_corr_ans:
                await call.answer('Верно!', show_alert=True)
            else:
                prompt = await utils.db.get_prompt_question(
                    callback_data['id_question'],
                    callback_data['id_answer'],
                )
                error_msg = f"Неверно.\n{prompt}"
                await call.answer(error_msg, show_alert=True)
    await call.answer()
