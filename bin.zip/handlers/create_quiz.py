from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters.state import State, StatesGroup
from conf import dp, bot, memory_storage, conn, cursor
import keyboards
from aiogram.utils.markdown import hide_link
import utils


class CreateQuiz(StatesGroup):
    question = State()
    photo = State()
    answer_options = State()
    true_answer = State()
    description = State()
    cost_que = State()


@dp.message_handler(text='🛠 Создать опрос')
async def create_user_step_one(msg: types.Message):
    """ хэндлер создания опроса """
    await bot.send_message(msg.from_user.id, 'Отправьте текст вашей викторины:')
    await CreateQuiz.question.set()


@dp.message_handler(state=CreateQuiz.question, content_types=types.ContentTypes.TEXT)
async def create_user_email(msg: types.Message, state: FSMContext):
    """ Сохрание вопроса, запрос картинки """
    await state.update_data(question=msg.text)
    await bot.send_message(msg.from_user.id, 'Отправь картинку:')
    await CreateQuiz.next()


@dp.message_handler(state=CreateQuiz.photo, content_types=types.ContentTypes.TEXT)
async def create_user_pass(msg: types.Message, state: FSMContext):
    """ сохранение картинки, запрос вариантов ответа """
    await state.update_data(link_photo=msg.text)
    await bot.send_message(msg.from_user.id, 'Отправьте варианты ответа:')
    await CreateQuiz.next()


@dp.message_handler(state=CreateQuiz.answer_options, content_types=types.ContentTypes.TEXT)
async def true_answer(msg: types.Message, state: FSMContext):
    """ преобразование вариантов ответа (с подсказками), запрос пояснения """
    all_opt = msg.text
    temp_answers = all_opt.split('\n')
    print(temp_answers)
    answers = []
    all_answers = []
    cnt = 1
    for i in temp_answers:
        lst_ans = i.split(' - ')
        if len(lst_ans) == 1:
            lst_ans.append(' ')
        all_answers.append((cnt, lst_ans[0], lst_ans[1]))
        answers.append({'number': cnt, 'answer': lst_ans[0],})
        cnt += 1
    print(answers)
    await state.update_data(all_answer=all_answers)
    await state.update_data(answers=answers)
    await bot.send_message(msg.from_user.id, 'Введите номер правильного ответа:')
    await CreateQuiz.next()


@dp.message_handler(state=CreateQuiz.true_answer, content_types=types.ContentTypes.TEXT)
async def create_quiz_description(msg: types.Message, state: FSMContext):
    """ Сохрание правильного вопроса, запрос стоимости """
    quiz_info = await state.get_data()
    try:
        true_ans = int(msg.text)
        if len(quiz_info['answers']) < true_ans:
            await bot.send_message(msg.from_user.id, 'Нет ответа с таким номером.')
            return
    except ValueError:
        await bot.send_message(msg.from_user.id, 'Номер должен быть числом')
        return
    await state.update_data(true_answer=msg.text)
    await bot.send_message(msg.from_user.id, 'Введите описание правильного ответа:')
    await CreateQuiz.next()


@dp.message_handler(state=CreateQuiz.description, content_types=types.ContentTypes.TEXT)
async def cost_question(msg: types.Message, state: FSMContext):
    """ сохранение описания, запрос стоимости (вознаграждения) """
    await state.update_data(description=msg.text)
    await bot.send_message(msg.from_user.id, 'Введите стоимость вопроса:')
    await CreateQuiz.next()


@dp.message_handler(state=CreateQuiz.cost_que, content_types=types.ContentTypes.TEXT)
async def finish_create_quiz(msg: types.Message, state: FSMContext):
    """ сохранение стоимости, отправка созданного опроса """
    await state.update_data(cost=msg.text)
    quiz_info = await state.get_data()
    print(quiz_info)
    temp_text = (
        f"{hide_link(quiz_info['link_photo'])}"
        f"{quiz_info['question']}\n"
    )
    print(temp_text)
    try:
        quiz_info['cost'] = float(quiz_info['cost'])
    except ValueError:
        await bot.send_message(msg.from_user.id, 'Цена введена неправильно (не число)')
        return

    await state.finish()
    tmp_answers = []
    for i in quiz_info['answers']:
        tmp_answers.append(i.get('answer'))
    all_answers = ' - '.join(tmp_answers)
    id_question = await utils.db.create_question(
        int(quiz_info['true_answer']),
        float(quiz_info['cost']),
        all_answers,
        temp_text,
        quiz_info['description'],
    )
    temp_text += f"\n\nСтоимость: {quiz_info['cost']}\nСтатус вопроса: #открыт"

    await bot.send_message(msg.from_user.id, 'Спасибо!')
    tmp_send_msg = await bot.send_message(
        utils.config.channel_id, temp_text, parse_mode=types.ParseMode.HTML,
        reply_markup=keyboards.inline.inline_answer_options(
            id_question, quiz_info['answers'],
            quiz_info['true_answer'], quiz_info['cost'])
    )
    msg_id = tmp_send_msg['message_id']
    await utils.db.insert_all_answers_question(id_question, quiz_info['all_answer'])
    # добавляем ID сообщения
    await utils.db.update_msg_id_question(id_question, msg_id)
    # ставим статус неактивен прошлому опросу
    await utils.db.update_state_question(id_question-1, False)
    prev_quiz = await utils.db.get_id_msg_question(id_question-1)
    if prev_quiz:
        msg_prev_quiz = (
            f"{prev_quiz[1]}\n\n"
            f"Правильный ответ - {prev_quiz[2]}\n"
            "статус: #закрыт"
        )
        await bot.edit_message_text(msg_prev_quiz, utils.config.channel_id, prev_quiz[0],
                                    parse_mode=types.ParseMode.HTML,
                                    reply_markup=keyboards.inline.inline_results_question(id_question-1))
