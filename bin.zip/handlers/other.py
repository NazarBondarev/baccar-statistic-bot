from aiogram import types
from conf import dp, bot
from keyboards.keyboards import main_keyboard


@dp.message_handler()
async def other_got_keyboard(msg: types.Message):
    """ ловим все лишние сообщения и предлагаем выбрать правильное действие с обновлением клавиутары """
    print(msg.get_args())
    await bot.send_message(msg.from_user.id, 'Выбери действие', reply_markup=main_keyboard(msg.from_user.id))


@dp.channel_post_handler()
async def other_channel_msg(msg: types.Message):
    print(msg)
    print(await bot.get_chat_member(msg.sender_chat.id, 456008920))