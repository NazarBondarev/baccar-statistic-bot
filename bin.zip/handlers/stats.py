from aiogram import types
from conf import dp, bot, memory_storage, conn, cursor
from aiogram.utils.callback_data import CallbackData
import keyboards
import utils


@dp.callback_query_handler(keyboards.inline.inline_rating.filter())
async def call_rating(call: types.CallbackQuery, callback_data: dict):
    """ обработка и вывод рейтингов """
    print(callback_data)
    r_type = callback_data['type']
    if r_type:
        rst = await utils.db.stat_rating(r_type)
        if rst:
            msg = ''
            for i in rst:
                msg = f"{msg} {i['fname']} - {i['rating']}\n"

            await bot.send_message(call.from_user.id, msg)
    await call.answer()
